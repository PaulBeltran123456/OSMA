Online Shopping with Marketing Analysis (OSMA)
GUI Design version 0.1
Note: In this version, this focuses more on just the features and basic layouting of objects within. Moreover, this wasn't fully finished due to possible adjustment.